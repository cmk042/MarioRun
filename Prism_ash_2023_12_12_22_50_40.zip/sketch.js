let img1;
let img2;
let img3;
let img4;
let img5;
let img6;
let animation =1;
let count = 0;
let lose = false;
let isjumping = false;
let h = 290;
let goombacount = 0;
let goombaposition = 400;
let firing = false;
let rand = 0;
let score = 0;

function setup() {
  createCanvas(400, 400);
  
}
function preload(){
  goomba = loadImage("images/goomba.png")
  run1 = loadImage("images/run1.png")
  run2 = loadImage("images/run2.png")
  run3 = loadImage("images/run3.png")
  jump = loadImage("images/jump.png")
  back = loadImage("images/background.png")
}
function draw() {
  if(lose){
    background(277,11,20);
    textSize(60);
    text("You Lose!",75,200);
    text("Score:", 75, 300)
    text(score, 260, 302)
  }
  else{
    background(back);
    textSize(60);
    text(score,350,60);
    checkcollision()
    fire();
    if(!isjumping){
        run(animation%3);
        count = count+1;
        if(count %4 ==0){
          animation = animation+1;
        if (mouseIsPressed){
          isjumping = true;
          count = 0;
        }
      }
    } 
    else{
      if (h < 290 || count ==0){
        count +=1;
        h = 290 -25*count + count*count;
        image(jump, 50, h, 60, 60);
      }
      else{
        isjumping = false
        count = 0;
      }
    } 
  }
}

function run(animation){
  if(animation == 0){
    image(run3, 50, h, 60, 60);
  }
  if(animation == 1){
    image(run2, 50, h, 60, 60);
  }
  if(animation == 2){
    image(run1, 50, h, 60, 60);
  }
}

function fire(){
  if (goombacount == rand){
    image(goomba, goombaposition, 290, 60, 60);
    goombaposition -= 10;
    if (goombaposition == 0){
      score +=1
      rand = int(random(45, 55));
      goombacount = 0;
      goombaposition = 400;
      
    }
  }
  else{
    goombacount += 1
  }
}

function checkcollision(){
  if (goombaposition < 75 & goombaposition > 25 & h > 270) {
    lose = true
  }
}